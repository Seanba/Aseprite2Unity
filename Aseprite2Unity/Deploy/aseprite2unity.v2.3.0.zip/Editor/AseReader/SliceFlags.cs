﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aseprite2Unity.Editor
{
    public enum SliceFlags : uint
    {
        Is9PatchSlice = 1,
        HasPivotInformation = 2,
    }
}
