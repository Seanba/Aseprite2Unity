﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aseprite2Unity.Editor
{
    public enum ColorProfileFlags : ushort
    {
        SpecialFixedGamma = 1,
    }
}
