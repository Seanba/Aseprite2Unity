Background artwork made with the Omega Team tileset by 'surt'
https://opengameart.org/content/omega-team