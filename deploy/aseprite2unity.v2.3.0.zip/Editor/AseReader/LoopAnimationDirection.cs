﻿namespace Aseprite2Unity.Editor
{
    public enum LoopAnimationDirection : byte
    {
        Forward = 0,
        Reverse = 1,
        PingPong = 2,
    }
}
