﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aseprite2Unity.Editor
{
    public enum ColorDepth : ushort
    {
        Indexed8 = 8,
        Grayscale16 = 16,
        RGBA32 = 32,
    }
}
