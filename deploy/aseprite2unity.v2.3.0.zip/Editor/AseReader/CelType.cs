﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aseprite2Unity.Editor
{
    public enum CelType : ushort
    {
        Raw = 0,
        Linked = 1,
        CompressedImage = 2,
    }
}
