﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aseprite2Unity.Editor
{
    public enum HeaderFlags : uint
    {
        HasLayerOpacity = 1,
    }
}
