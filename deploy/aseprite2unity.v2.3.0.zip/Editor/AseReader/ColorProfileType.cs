﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aseprite2Unity.Editor
{
    public enum ColorProfileType : ushort
    {
        NoColorProfile = 0,
        sRGB = 1,
        EmbeddedICC = 2,
    }
}
